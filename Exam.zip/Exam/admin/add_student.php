<?php
require '../db.php';
session_start();

if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit;
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $regno = trim($_POST['regno'] ?? '');
    $name = trim($_POST['name'] ?? '');
    $password = trim($_POST['password'] ?? '');
    $phone_number = trim($_POST['phone_number'] ?? '');
    
    // Validation
    if (empty($regno) || empty($name) || empty($password) || empty($phone_number)) {
        $error = "All fields are required";
    } elseif (strlen($password) < 6) {
        $error = "Password must be at least 6 characters long";
    } elseif (!preg_match('/^[0-9]{10}$/', $phone_number)) {
        $error = "Phone number must be 10 digits";
    } else {
        try {
            // Check if registration number already exists
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM students WHERE regno = ?");
            $stmt->execute([$regno]);
            if ($stmt->fetchColumn() > 0) {
                $error = "Registration number already exists";
            } else {
                // Hash password and insert new student
                $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
                $stmt = $pdo->prepare("INSERT INTO students (regno, name, password, phone_number) VALUES (?, ?, ?, ?)");
                $stmt->execute([$regno, $name, $hashedPassword, $phone_number]);
                $success = "Student added successfully";
            }
        } catch (PDOException $e) {
            $error = "A system error occurred. Please try again later.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Student - Rwanda Polytechnic</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-color: #1a73e8;
            --secondary-color: #4285f4;
            --success-color: #0f9d58;
            --danger-color: #d93025;
            --text-color: #202124;
            --border-color: #dadce0;
            --background-color: #f8f9fa;
        }
        * {margin:0;padding:0;box-sizing:border-box;}
        body {font-family:'Poppins',sans-serif;background:var(--background-color);color:var(--text-color);line-height:1.6;}
        .container {display:flex;min-height:100vh;}
        .sidebar {width:250px;background:white;padding:2rem;box-shadow:2px 0 5px rgba(0,0,0,0.1);}
        .main-content {flex:1;padding:2rem;}
        .logo {text-align:center;margin-bottom:2rem;}
        .logo h1 {color:var(--primary-color);font-size:1.5rem;margin-bottom:0.5rem;}
        .nav-menu {list-style:none;}
        .nav-item {margin-bottom:0.5rem;}
        .nav-link {display:flex;align-items:center;padding:0.75rem 1rem;color:var(--text-color);text-decoration:none;border-radius:4px;transition:background-color 0.2s;}
        .nav-link:hover,.nav-link.active {background:var(--background-color);color:var(--primary-color);}
        .nav-link i {margin-right:0.75rem;width:20px;text-align:center;}
        .header-bar {display:flex;justify-content:space-between;align-items:center;margin-bottom:1.5rem;}
        .header-bar h2 {font-size:1.5rem;}
        .form-container {background:white;padding:2rem;border-radius:8px;box-shadow:0 2px 4px rgba(0,0,0,0.1);max-width:600px;margin:0 auto;}
        .form-group {margin-bottom:1.5rem;}
        .form-group label {display:block;margin-bottom:0.5rem;font-weight:500;}
        .form-control {width:100%;padding:0.75rem;border:1px solid var(--border-color);border-radius:4px;font-size:1rem;}
        .form-control:focus {outline:none;border-color:var(--primary-color);box-shadow:0 0 0 2px rgba(26,115,232,0.2);}
        .btn {padding:0.75rem 1.5rem;border:none;border-radius:4px;cursor:pointer;font-weight:500;transition:background-color 0.2s;}
        .btn-primary {background:var(--primary-color);color:white;}
        .btn-primary:hover {background:var(--secondary-color);}
        .alert {padding:1rem;border-radius:4px;margin-bottom:1rem;}
        .alert-success {background:#e6f4ea;color:var(--success-color);}
        .alert-danger {background:#fce8e6;color:var(--danger-color);}
        .btn-back {display:inline-flex;align-items:center;gap:0.5rem;color:var(--primary-color);text-decoration:none;margin-bottom:1rem;}
        .btn-back:hover {text-decoration:underline;}
        .password-requirements {font-size:0.875rem;color:#5f6368;margin-top:0.5rem;}
        @media (max-width:768px){.container{flex-direction:column;}.sidebar{width:100%;padding:1rem;}.main-content{padding:1rem;}}
    </style>
</head>
<body>
<div class="container">
    <div class="sidebar">
        <div class="logo">
            <h1>Rwanda Polytechnic</h1>
            <p>Admin Portal</p>
        </div>
        <ul class="nav-menu">
            <li class="nav-item"><a href="dashboard.php" class="nav-link"><i class="fas fa-home"></i>Dashboard</a></li>
            <li class="nav-item"><a href="appeals.php" class="nav-link"><i class="fas fa-gavel"></i>Appeals</a></li>
            <li class="nav-item"><a href="students.php" class="nav-link active"><i class="fas fa-user-graduate"></i>Students</a></li>
            <li class="nav-item"><a href="modules.php" class="nav-link"><i class="fas fa-book"></i>Modules</a></li>
            <li class="nav-item"><a href="logout.php" class="nav-link"><i class="fas fa-sign-out-alt"></i>Logout</a></li>
        </ul>
    </div>
    <div class="main-content">
        <a href="students.php" class="btn-back"><i class="fas fa-arrow-left"></i> Back to Students</a>
        
        <div class="header-bar">
            <h2>Add New Student</h2>
        </div>

        <div class="form-container">
            <?php if ($error): ?>
                <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
            <?php endif; ?>

            <form method="post" novalidate>
                <div class="form-group">
                    <label for="regno">Registration Number</label>
                    <input type="text" 
                           id="regno" 
                           name="regno" 
                           class="form-control" 
                           required 
                           value="<?php echo isset($_POST['regno']) ? htmlspecialchars($_POST['regno']) : ''; ?>"
                           placeholder="Enter registration number">
                </div>

                <div class="form-group">
                    <label for="name">Full Name</label>
                    <input type="text" 
                           id="name" 
                           name="name" 
                           class="form-control" 
                           required 
                           value="<?php echo isset($_POST['name']) ? htmlspecialchars($_POST['name']) : ''; ?>"
                           placeholder="Enter full name">
                </div>

                <div class="form-group">
                    <label for="phone_number">Phone Number</label>
                    <input type="tel" 
                           id="phone_number" 
                           name="phone_number" 
                           class="form-control" 
                           required 
                           pattern="[0-9]{10}"
                           value="<?php echo isset($_POST['phone_number']) ? htmlspecialchars($_POST['phone_number']) : ''; ?>"
                           placeholder="Enter 10-digit phone number">
                </div>

                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" 
                           id="password" 
                           name="password" 
                           class="form-control" 
                           required 
                           minlength="6"
                           placeholder="Enter password">
                    <div class="password-requirements">
                        Password must be at least 6 characters long
                    </div>
                </div>

                <button type="submit" class="btn btn-primary">Add Student</button>
            </form>
        </div>
    </div>
</div>
</body>
</html> 