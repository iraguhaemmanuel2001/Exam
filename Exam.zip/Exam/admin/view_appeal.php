<?php
require '../db.php';
session_start();

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit;
}

// Get appeal ID from URL
$appealId = $_GET['id'] ?? null;

if (!$appealId) {
    header("Location: appeals.php");
    exit;
}

// Get appeal details
$stmt = $pdo->prepare("
    SELECT a.*, s.regno, s.name as student_name, m.module_name, mk.mark
    FROM appeals a 
    JOIN students s ON a.student_regno = s.regno 
    JOIN modules m ON a.module_id = m.id 
    JOIN marks mk ON mk.student_regno = s.regno AND mk.module_id = m.id
    WHERE a.id = ?
");
$stmt->execute([$appealId]);
$appeal = $stmt->fetch();

if (!$appeal) {
    header("Location: appeals.php");
    exit;
}

// Handle status update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['status'])) {
    $status = $_POST['status'];
    $comment = $_POST['comment'] ?? '';

    try {
        $stmt = $pdo->prepare("UPDATE appeals SET status = ?, admin_comment = ?, updated_at = NOW() WHERE id = ?");
        $stmt->execute([$status, $comment, $appealId]);
        header("Location: appeals.php?success=1");
        exit;
    } catch (PDOException $e) {
        $error = "Failed to update appeal status.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Appeal - Rwanda Polytechnic</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-color: #1a73e8;
            --secondary-color: #4285f4;
            --success-color: #0f9d58;
            --warning-color: #f4b400;
            --danger-color: #d93025;
            --text-color: #202124;
            --border-color: #dadce0;
            --background-color: #f8f9fa;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: var(--background-color);
            color: var(--text-color);
            line-height: 1.6;
        }

        .container {
            display: flex;
            min-height: 100vh;
        }

        .sidebar {
            width: 250px;
            background: white;
            padding: 2rem;
            box-shadow: 2px 0 5px rgba(0, 0, 0, 0.1);
        }

        .main-content {
            flex: 1;
            padding: 2rem;
        }

        .logo {
            text-align: center;
            margin-bottom: 2rem;
        }

        .logo h1 {
            color: var(--primary-color);
            font-size: 1.5rem;
            margin-bottom: 0.5rem;
        }

        .nav-menu {
            list-style: none;
        }

        .nav-item {
            margin-bottom: 0.5rem;
        }

        .nav-link {
            display: flex;
            align-items: center;
            padding: 0.75rem 1rem;
            color: var(--text-color);
            text-decoration: none;
            border-radius: 4px;
            transition: background-color 0.2s;
        }

        .nav-link:hover, .nav-link.active {
            background: var(--background-color);
            color: var(--primary-color);
        }

        .nav-link i {
            margin-right: 0.75rem;
            width: 20px;
            text-align: center;
        }

        .appeal-details {
            background: white;
            padding: 2rem;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            margin-bottom: 1.5rem;
        }

        .appeal-details h2 {
            color: var(--text-color);
            margin-bottom: 1.5rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid var(--border-color);
        }

        .detail-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1.5rem;
            margin-bottom: 1.5rem;
        }

        .detail-item {
            margin-bottom: 1rem;
        }

        .detail-item label {
            display: block;
            font-weight: 500;
            margin-bottom: 0.5rem;
            color: var(--text-color);
        }

        .detail-item .value {
            color: #5f6368;
        }

        .status-form {
            background: white;
            padding: 2rem;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .status-form h3 {
            color: var(--text-color);
            margin-bottom: 1.5rem;
        }

        .form-group {
            margin-bottom: 1.5rem;
        }

        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 500;
        }

        .form-control {
            width: 100%;
            padding: 0.75rem;
            border: 1px solid var(--border-color);
            border-radius: 4px;
            font-size: 1rem;
            font-family: inherit;
        }

        .form-control:focus {
            outline: none;
            border-color: var(--primary-color);
            box-shadow: 0 0 0 2px rgba(26, 115, 232, 0.2);
        }

        textarea.form-control {
            min-height: 100px;
            resize: vertical;
        }

        .btn {
            padding: 0.75rem 1.5rem;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-weight: 500;
            transition: background-color 0.2s;
        }

        .btn-primary {
            background: var(--primary-color);
            color: white;
        }

        .btn-primary:hover {
            background: var(--secondary-color);
        }

        .status-badge {
            padding: 0.25rem 0.75rem;
            border-radius: 20px;
            font-size: 0.875rem;
            font-weight: 500;
            display: inline-block;
        }

        .status-pending {
            background: #fff3e0;
            color: var(--warning-color);
        }

        .status-approved {
            background: #e6f4ea;
            color: var(--success-color);
        }

        .status-rejected {
            background: #fce8e6;
            color: var(--danger-color);
        }

        .error-message {
            background: #fce8e6;
            color: var(--danger-color);
            padding: 1rem;
            border-radius: 4px;
            margin-bottom: 1rem;
        }

        @media (max-width: 768px) {
            .container {
                flex-direction: column;
            }

            .sidebar {
                width: 100%;
                padding: 1rem;
            }

            .main-content {
                padding: 1rem;
            }

            .detail-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="sidebar">
            <div class="logo">
                <h1>Rwanda Polytechnic</h1>
                <p>Admin Portal</p>
            </div>
            <ul class="nav-menu">
                <li class="nav-item">
                    <a href="dashboard.php" class="nav-link">
                        <i class="fas fa-home"></i>
                        Dashboard
                    </a>
                </li>
                <li class="nav-item">
                    <a href="appeals.php" class="nav-link active">
                        <i class="fas fa-gavel"></i>
                        Appeals
                    </a>
                </li>
                <li class="nav-item">
                    <a href="students.php" class="nav-link">
                        <i class="fas fa-user-graduate"></i>
                        Students
                    </a>
                </li>
                <li class="nav-item">
                    <a href="modules.php" class="nav-link">
                        <i class="fas fa-book"></i>
                        Modules
                    </a>
                </li>
                <li class="nav-item">
                    <a href="logout.php" class="nav-link">
                        <i class="fas fa-sign-out-alt"></i>
                        Logout
                    </a>
                </li>
            </ul>
        </div>

        <div class="main-content">
            <?php if (isset($error)): ?>
                <div class="error-message">
                    <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>

            <div class="appeal-details">
                <h2>Appeal Details</h2>
                <div class="detail-grid">
                    <div class="detail-item">
                        <label>Student Name</label>
                        <div class="value"><?php echo htmlspecialchars($appeal['student_name']); ?></div>
                    </div>
                    <div class="detail-item">
                        <label>Registration Number</label>
                        <div class="value"><?php echo htmlspecialchars($appeal['regno']); ?></div>
                    </div>
                    <div class="detail-item">
                        <label>Module</label>
                        <div class="value"><?php echo htmlspecialchars($appeal['module_name']); ?></div>
                    </div>
                    <div class="detail-item">
                        <label>Current Mark</label>
                        <div class="value"><?php echo htmlspecialchars($appeal['mark']); ?></div>
                    </div>
                    <div class="detail-item">
                        <label>Status</label>
                        <div class="value">
                            <span class="status-badge status-<?php echo strtolower($appeal['status']); ?>">
                                <?php echo ucfirst($appeal['status']); ?>
                            </span>
                        </div>
                    </div>
                    <div class="detail-item">
                        <label>Submitted On</label>
                        <div class="value"><?php echo date('F d, Y H:i', strtotime($appeal['created_at'])); ?></div>
                    </div>
                </div>
                <div class="detail-item">
                    <label>Appeal Reason</label>
                    <div class="value"><?php echo nl2br(htmlspecialchars($appeal['reason'])); ?></div>
                </div>
                <?php if ($appeal['admin_comment']): ?>
                    <div class="detail-item">
                        <label>Admin Comment</label>
                        <div class="value"><?php echo nl2br(htmlspecialchars($appeal['admin_comment'])); ?></div>
                    </div>
                <?php endif; ?>
            </div>

            <?php if ($appeal['status'] === 'pending'): ?>
                <div class="status-form">
                    <h3>Update Appeal Status</h3>
                    <form method="POST">
                        <div class="form-group">
                            <label for="status">Status</label>
                            <select name="status" id="status" class="form-control" required>
                                <option value="approved">Approve</option>
                                <option value="rejected">Reject</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="comment">Comment</label>
                            <textarea name="comment" id="comment" class="form-control" 
                                    placeholder="Enter your response to the student's appeal"></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary">Update Status</button>
                    </form>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html> 