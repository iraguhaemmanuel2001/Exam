<?php
require '../db.php';
session_start();

if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit;
}

$error = '';
$success = '';

// Handle mark submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $student_id = $_POST['student_id'] ?? '';
    $module_id = $_POST['module_id'] ?? '';
    $mark = $_POST['mark'] ?? '';
    
    if (empty($student_id) || empty($module_id) || empty($mark)) {
        $error = "All fields are required";
    } elseif (!is_numeric($mark) || $mark < 0 || $mark > 100) {
        $error = "Mark must be a number between 0 and 100";
    } else {
        try {
            // Check if mark already exists
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM marks WHERE student_id = ? AND module_id = ?");
            $stmt->execute([$student_id, $module_id]);
            if ($stmt->fetchColumn() > 0) {
                $error = "Mark already exists for this student and module";
            } else {
                // Insert new mark
                $stmt = $pdo->prepare("INSERT INTO marks (student_id, module_id, mark) VALUES (?, ?, ?)");
                $stmt->execute([$student_id, $module_id, $mark]);
                $success = "Mark added successfully";
            }
        } catch (PDOException $e) {
            $error = "A system error occurred. Please try again later.";
        }
    }
}

// Fetch all students
$stmt = $pdo->query("SELECT id, regno, name FROM students ORDER BY name");
$students = $stmt->fetchAll();

// Fetch all modules
$stmt = $pdo->query("SELECT id, module_name FROM modules ORDER BY module_name");
$modules = $stmt->fetchAll();

// Fetch all marks with student and module details
$stmt = $pdo->query("
    SELECT m.*, s.regno, s.name as student_name, md.module_name 
    FROM marks m 
    JOIN students s ON m.student_id = s.id 
    JOIN modules md ON m.module_id = md.id 
    ORDER BY s.name, md.module_name
");
$marks = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Marks - Rwanda Polytechnic</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-color: #1a73e8;
            --secondary-color: #4285f4;
            --success-color: #0f9d58;
            --danger-color: #d93025;
            --text-color: #202124;
            --border-color: #dadce0;
            --background-color: #f8f9fa;
        }
        * {margin:0;padding:0;box-sizing:border-box;}
        body {font-family:'Poppins',sans-serif;background:var(--background-color);color:var(--text-color);line-height:1.6;}
        .container {display:flex;min-height:100vh;}
        .sidebar {width:250px;background:white;padding:2rem;box-shadow:2px 0 5px rgba(0,0,0,0.1);}
        .main-content {flex:1;padding:2rem;}
        .logo {text-align:center;margin-bottom:2rem;}
        .logo h1 {color:var(--primary-color);font-size:1.5rem;margin-bottom:0.5rem;}
        .nav-menu {list-style:none;}
        .nav-item {margin-bottom:0.5rem;}
        .nav-link {display:flex;align-items:center;padding:0.75rem 1rem;color:var(--text-color);text-decoration:none;border-radius:4px;transition:background-color 0.2s;}
        .nav-link:hover,.nav-link.active {background:var(--background-color);color:var(--primary-color);}
        .nav-link i {margin-right:0.75rem;width:20px;text-align:center;}
        .header-bar {display:flex;justify-content:space-between;align-items:center;margin-bottom:1.5rem;}
        .header-bar h2 {font-size:1.5rem;}
        .form-container {background:white;padding:2rem;border-radius:8px;box-shadow:0 2px 4px rgba(0,0,0,0.1);margin-bottom:2rem;}
        .form-group {margin-bottom:1.5rem;}
        .form-group label {display:block;margin-bottom:0.5rem;font-weight:500;}
        .form-control {width:100%;padding:0.75rem;border:1px solid var(--border-color);border-radius:4px;font-size:1rem;}
        .form-control:focus {outline:none;border-color:var(--primary-color);box-shadow:0 0 0 2px rgba(26,115,232,0.2);}
        .btn {padding:0.75rem 1.5rem;border:none;border-radius:4px;cursor:pointer;font-weight:500;transition:background-color 0.2s;}
        .btn-primary {background:var(--primary-color);color:white;}
        .btn-primary:hover {background:var(--secondary-color);}
        .alert {padding:1rem;border-radius:4px;margin-bottom:1rem;}
        .alert-success {background:#e6f4ea;color:var(--success-color);}
        .alert-danger {background:#fce8e6;color:var(--danger-color);}
        .marks-table {width:100%;background:white;border-radius:8px;box-shadow:0 2px 4px rgba(0,0,0,0.1);border-collapse:collapse;}
        .marks-table th,.marks-table td {padding:1rem;text-align:left;border-bottom:1px solid var(--border-color);}
        .marks-table th {font-weight:500;color:var(--text-color);background:var(--background-color);}
        .action-btn {padding:0.25rem 0.75rem;border:none;border-radius:4px;cursor:pointer;font-weight:500;transition:background-color 0.2s;text-decoration:none;display:inline-block;}
        .edit-btn {background:var(--success-color);color:white;}
        .edit-btn:hover {background:#0b7d43;}
        .delete-btn {background:var(--danger-color);color:white;}
        .delete-btn:hover {background:#b71c1c;}
        @media (max-width:768px){.container{flex-direction:column;}.sidebar{width:100%;padding:1rem;}.main-content{padding:1rem;}}
    </style>
</head>
<body>
<div class="container">
    <div class="sidebar">
        <div class="logo">
            <h1>Rwanda Polytechnic</h1>
            <p>Admin Portal</p>
        </div>
        <ul class="nav-menu">
            <li class="nav-item"><a href="dashboard.php" class="nav-link"><i class="fas fa-home"></i>Dashboard</a></li>
            <li class="nav-item"><a href="appeals.php" class="nav-link"><i class="fas fa-gavel"></i>Appeals</a></li>
            <li class="nav-item"><a href="students.php" class="nav-link"><i class="fas fa-user-graduate"></i>Students</a></li>
            <li class="nav-item"><a href="modules.php" class="nav-link"><i class="fas fa-book"></i>Modules</a></li>
            <li class="nav-item"><a href="marks.php" class="nav-link active"><i class="fas fa-chart-bar"></i>Marks</a></li>
            <li class="nav-item"><a href="logout.php" class="nav-link"><i class="fas fa-sign-out-alt"></i>Logout</a></li>
        </ul>
    </div>
    <div class="main-content">
        <div class="header-bar">
            <h2>Manage Student Marks</h2>
        </div>

        <div class="form-container">
            <?php if ($error): ?>
                <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
            <?php endif; ?>

            <form method="post" novalidate>
                <div class="form-group">
                    <label for="student_id">Student</label>
                    <select id="student_id" name="student_id" class="form-control" required>
                        <option value="">Select Student</option>
                        <?php foreach ($students as $student): ?>
                            <option value="<?php echo $student['id']; ?>">
                                <?php echo htmlspecialchars($student['regno'] . ' - ' . $student['name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label for="module_id">Module</label>
                    <select id="module_id" name="module_id" class="form-control" required>
                        <option value="">Select Module</option>
                        <?php foreach ($modules as $module): ?>
                            <option value="<?php echo $module['id']; ?>">
                                <?php echo htmlspecialchars($module['module_name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label for="mark">Mark (0-100)</label>
                    <input type="number" 
                           id="mark" 
                           name="mark" 
                           class="form-control" 
                           required 
                           min="0"
                           max="100"
                           step="0.1"
                           placeholder="Enter mark">
                </div>

                <button type="submit" class="btn btn-primary">Add Mark</button>
            </form>
        </div>

        <table class="marks-table">
            <thead>
                <tr>
                    <th>Student</th>
                    <th>Module</th>
                    <th>Mark</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($marks as $mark): ?>
                <tr>
                    <td><?php echo htmlspecialchars($mark['regno'] . ' - ' . $mark['student_name']); ?></td>
                    <td><?php echo htmlspecialchars($mark['module_name']); ?></td>
                    <td><?php echo htmlspecialchars($mark['mark']); ?></td>
                    <td>
                        <a href="#" class="action-btn edit-btn"><i class="fas fa-edit"></i> Edit</a>
                        <a href="#" class="action-btn delete-btn"><i class="fas fa-trash"></i> Delete</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
</body>
</html> 