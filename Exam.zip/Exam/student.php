<?php
// Get the variables sent via POST from the USSD gateway
$sessionId   = $_POST["sessionId"];
$serviceCode = $_POST["serviceCode"];
$phoneNumber = $_POST["phoneNumber"];
$text        = $_POST["text"];

require 'db.php'; // include DB connection

// Explode user input to track levels in the menu
$inputArray = explode("*", $text);
$level = count($inputArray);

if ($text == "") {
    // Main menu
    $response  = "CON Welcome to the Marks Appeal System\n\n";
    $response .= "1. Check my marks\n";
    $response .= "2. Appeal my marks";
} else if ($inputArray[0] == "1") {
    // Check Marks
    if ($level == 1) {
        $response = "CON Please enter your Student Registration Number:";
    } else {
        $studentRegno = $inputArray[1];
        $stmt = $pdo->prepare("SELECT m.module_name, mk.mark FROM marks mk JOIN modules m ON mk.module_id = m.id WHERE mk.student_regno = ?");
        $stmt->execute([$studentRegno]);
        $marks = $stmt->fetchAll();

        if ($marks) {
            $response = "END Your Marks:\n\n";
            foreach ($marks as $m) {
                $response .= "{$m['module_name']}: {$m['mark']}\n";
            }
            $response .= "\nThank you for using our service.";
        } else {
            $response = "END Registration number not found.\nPlease verify and try again.";
        }
    }
} else if ($inputArray[0] == "2") {
    // Appeal process
    if ($level == 1) {
        $response = "CON Please enter your Student Registration Number:";
    } else if ($level == 2) {
        $studentRegno = $inputArray[1];
        // fetch modules
        $stmt = $pdo->prepare("SELECT m.module_name, mk.mark, m.id FROM marks mk JOIN modules m ON mk.module_id = m.id WHERE mk.student_regno = ?");
        $stmt->execute([$studentRegno]);
        $modules = $stmt->fetchAll();

        if ($modules) {
            $response = "CON Select the module to appeal:\n\n";
            foreach ($modules as $index => $mod) {
                $response .= ($index + 1) . ". {$mod['module_name']}: {$mod['mark']}\n";
            }
            $response .= "\nEnter the number of your choice:";
        } else {
            $response = "END Registration number not found.\nPlease verify and try again.";
        }
    } else if ($level == 3) {
        $moduleIndex = (int)$inputArray[2] - 1;
        $studentRegno = $inputArray[1];
        // Fetch the correct module
        $stmt = $pdo->prepare("SELECT m.module_name, mk.mark, m.id FROM marks mk JOIN modules m ON mk.module_id = m.id WHERE mk.student_regno = ?");
        $stmt->execute([$studentRegno]);
        $modules = $stmt->fetchAll();
        $selectedModule = $modules[$moduleIndex] ?? null;

        if ($selectedModule) {
            $response = "CON Please provide your reason for appeal:\n";
            $response .= "Be specific and include any relevant details.\n";
            $response .= "Maximum 160 characters.";
        } else {
            $response = "END Invalid module selection.\nPlease try again.";
        }
    } else if ($level == 4) {
        $studentRegno = $inputArray[1];
        $moduleIndex = (int)$inputArray[2] - 1;
        $reason = trim(end($inputArray));

        try {
            // Fetch module id
            $stmt = $pdo->prepare("SELECT m.id FROM marks mk JOIN modules m ON mk.module_id = m.id WHERE mk.student_regno = ?");
            $stmt->execute([$studentRegno]);
            $modules = $stmt->fetchAll();

            if (isset($modules[$moduleIndex])) {
                $moduleId = $modules[$moduleIndex]['id'];

                // Insert appeal
                $stmt = $pdo->prepare("INSERT INTO appeals(student_regno, module_id, reason, status) VALUES (?, ?, ?, 'pending')");
                $stmt->execute([$studentRegno, $moduleId, $reason]);

                $response = "END Thank you for submitting your appeal.\n";
                $response .= "Your appeal has been received and will be reviewed.\n";
                $response .= "You will be notified of the outcome.";
            } else {
                $response = "END Invalid module selected.\nPlease try again.";
            }
        } catch (Exception $e) {
            $response = "END Sorry, a system error occurred.\nPlease try again later.";
        }
    }
} else {
    $response = "END Invalid input.\nPlease try again.";
}

header('Content-type: text/plain');
echo $response;
